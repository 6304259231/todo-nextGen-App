import { Component } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { AsideComponent } from '../aside/aside.component';

@Component({
  selector: 'app-wrapper',
  imports: [ DashboardComponent, AsideComponent],
  templateUrl: './wrapper.component.html',
  styleUrl: './wrapper.component.css'
})
export class WrapperComponent {

}
